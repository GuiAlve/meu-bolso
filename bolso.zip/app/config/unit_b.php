<?php
return [
    'host'  =>  "",
    'port'  =>  "",
    'name'  =>  "app/database/unit_b.db",
    'user'  =>  "",
    'pass'  =>  "",
    'type'  =>  "sqlite",
    'prep'  =>  "1"
];